# HR AI MLOps on Databricks

This project provides a **config-driven**, reusable Python codebase for HR AI MLOps on Databricks.
It reads curated data from the **Gold** layer, builds model outputs, and writes prediction tables that can be consumed by Power BI semantic models and executive dashboards.

## Supported Use Cases

1. Employee Attrition Prediction (30/60/90 days)
2. Workforce Demand Forecasting
3. Flight Risk Prediction (key talent)
4. Internal Mobility Recommendations
5. Diversity and Inclusion Trend Forecasting
6. Compensation Anomaly Detection
7. Executive Workforce Health Score

## Project Structure

- `configs/base_config.yaml`: all table names, column mappings, and model options
- `configs/base_config_powerbi_model.yaml`: workbook-aligned mapping template based on your Power BI data model file
- `configs/base_config_workbook_strict.yaml`: strict mapping profile using exact workbook physical model attribute names
- `configs/base_config_multitable_join.yaml`: multi-table Gold join profile (fact and dimension joins)
- `src/hr_mlops/pipelines/orchestrator.py`: end-to-end execution from Gold to output tables
- `src/hr_mlops/models/use_cases.py`: model logic for all use cases
- `jobs/run_databricks_job.py`: Databricks job entrypoint
- `databricks.yml`: Databricks Asset Bundle job definition

## Run in Databricks

You can run as a Databricks Python task:

```bash
python -m jobs.run_databricks_job --config configs/base_config.yaml
```

Or package and run using Databricks Asset Bundles:

```bash
databricks bundle deploy
databricks bundle run hr_ai_mlops_pipeline
```

## Configuration-first Design

Column names and feature fields are mapped in `configs/base_config.yaml` under `column_mappings` and each use-case section, making it easy to reuse this project for other models and source systems.

The source can be provided in either of these forms under `source`:

- `gold_hr_table`: a single curated Gold table
- `sql_query`: a SQL statement that joins multiple Gold tables and projects final feature columns

## MLflow Tracking

The pipeline supports MLflow run tracking through config:

- `mlflow.enabled`: enable/disable tracking
- `mlflow.experiment`: experiment path in Databricks workspace
- `mlflow.run_name`: run display name
- `mlflow.tags`: metadata tags

The pipeline logs run params and row-count metrics for all output tables.

## Workbook Mapping Notes

From your workbook (`Data Model-Power BI.xlsx`), these sheets were detected:

- `Physical Model derived frm file`
- `Model Type`
- `Model Object`
- `KPI`

Use `configs/base_config_powerbi_model.yaml` as a starting point, then replace each `column_mappings` value with exact Gold-layer column names from Databricks.

For direct workbook-attribute execution, use:

```bash
python -m jobs.run_databricks_job --config configs/base_config_workbook_strict.yaml
```

If your Gold table uses different casing or naming, update only `column_mappings` and keep the rest of the profile unchanged.

For multi-table Gold joins, use:

```bash
python -m jobs.run_databricks_job --config configs/base_config_multitable_join.yaml
```
