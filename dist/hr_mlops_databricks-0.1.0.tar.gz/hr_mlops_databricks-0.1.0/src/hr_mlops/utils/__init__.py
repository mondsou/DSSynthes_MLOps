"""Shared utility functions."""
