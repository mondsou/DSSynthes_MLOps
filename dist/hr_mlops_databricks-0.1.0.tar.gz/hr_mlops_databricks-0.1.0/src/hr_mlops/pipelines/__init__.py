"""Pipeline orchestration layer."""
